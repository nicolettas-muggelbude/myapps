"""
MyApps - Tool zum Auflisten und Verwalten installierter Linux-Anwendungen

Version: 0.2.0
Lizenz: GPLv3.0
"""

__version__ = "0.2.0"
__author__ = "MyApps Contributors"
__license__ = "GPLv3.0"
